package minesweeper;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import java.util.Timer;


public class CE203_1903519_Ass2{
    //GETTERS
    public static JFrame getMyFrame() {
        return myFrame;
    }
    public static JPanel getMyPanel() {
        return myPanel;
    }
    public static JRadioButton getSmallGrid() {
        return smallGrid;
    }
    public static JRadioButton getBigGrid() {
        return bigGrid;
    }
    public static JButton getStartButton() {
        return startButton;
    }
    public static int getGridSize() {
        return gridSize;
    }
    public static Field getField(int r, int c) {
        return field[r][c];
    }
    public static int[] getBombs() {
        return bombs;
    }
    public static int getTenSecCounterInt() {
        return tenSecCounterInt;
    }
    public static JButton getT(int r, int c) {
        return t[r][c];
    }
    public static Game getGame() {
        return game;
    }



    //DECLARATIONS
    private static final JPanel myPanel = new JPanel();
    private static final JFrame myFrame = new JFrame("1903519");
    public static JButton[][] t ;
    private static int gridSize;
    private static final ButtonGroup G1 = new ButtonGroup();
    private static final JRadioButton smallGrid = new JRadioButton("10x10 - 20 COVID particles");
    private static final JRadioButton bigGrid = new JRadioButton("20x20 - 80 COVID particles");
    private static final JButton startButton = new JButton("Start");
    private static Field[][] field ;
    private static int[] bombs;
    public static int r;
    public static int c;
    private static int tenSecCounterInt = 0;
    static JLabel titleLabel;
    static JLabel textLabel;
    private static Game game;
    private static JLabel nameLabel;
    private static JTextField nameField;
    private static int[] vaccines;
    private static int[] facemasks;


    //SETTERS
    public static void setGridSize(int gridSize) {
        CE203_1903519_Ass2.gridSize = gridSize;
    }

    public static void main(String[] args){

        initialize(false);                   //CALLING STARTUP FUNCTION


    }
    static public void generateField() {

        game = new Game();
        field = new Field[CE203_1903519_Ass2.getGridSize()][CE203_1903519_Ass2.getGridSize()];      //SETTING FIELD SIZE
        //USING THE CONSTRUCTOR ON EVERY INSTANCE IN THE 2D FIELD ARRAY
        for(int r = 0; r < getGridSize(); r++) {
            for(int c = 0; c < getGridSize(); c++)
            {
                field[r][c] = new Field();
            }

        }
        //SETTING BOMBS ARRAY LENGTH WITH 20 AS DEFAULT

        if(getGridSize() == 20){
            bombs = new int[80];
            vaccines = new int[4];
            facemasks = new int[4];

        }
        else{
            bombs = new int[20];
            vaccines = new int[1];
            facemasks = new int[1];
        }


        //RANDOMIZING BOMBS TO GET UNIQUE NUMBERS EVERY TIME
        randomizeBomb();
        //RANDOMIZING THE VACCINES
        randomizeVaccine();
        //RANDOMIZING THE FACEMASKS
        randomizeFacemask();
        //ASSIGNING THE VALUE 9 TO EVERY BOMB FIELD IN THE 2D ARRAY
        assignBombInField();
        //ASSIGNING THE VALUE TRUE TO EVERY FACEMASK FIELD IN THE 2D ARRAY
        setFacemaskInField();
        //ASSIGNING THE VALUE TRUE TO EVERY VACCINE FIELD IN THE 2D ARRAY
        setVaccineInField();

        //COUNTING AND SETTING THE NUMBER OF BOMBS AROUND NON-BOMB FIELDS
        for( r = 0; r < getGridSize(); r++) {
            for( c = 0; c < getGridSize(); c++)
            {int counter = 0;
                if(!field[r][c].isChecked()){
                    if(r!=0){
                        if(field[r-1][c].getValue()==9){
                            counter++;
                        }
                    }
                    if(c!=0){
                        if(field[r][c-1].getValue()==9){
                            counter++;
                        }
                    }
                    if(r != (getGridSize()-1)){
                        if(field[r+1][c].getValue()==9){
                            counter++;
                        }
                    }
                    if(c != (getGridSize()-1)){
                        if(field[r][c+1].getValue()==9){
                            counter++;
                        }
                    }
                    if(r!= 0 && c!=0){
                        if(field[r-1][c-1].getValue()==9){
                            counter++;
                        }
                    }
                    if(r!= 0 && c != (getGridSize()-1)){
                        if(field[r-1][c+1].getValue()==9){
                            counter++;
                        }
                    }
                    if(r != (getGridSize()-1) && c != (getGridSize()-1)){
                        if(field[r+1][c+1].getValue()==9){
                            counter++;
                        }
                    }
                    if(r != (getGridSize()-1) && c != 0){
                        if(field[r+1][c-1].getValue()==9){
                            counter++;
                        }
                    }
                    field[r][c].setValue(counter);
                    field[r][c].setChecked(true);
                }
            }
        }
        //CORE FUNCTIONALITY OF THE GAME
        for(r = 0; r < getGridSize(); r++) {
            for(c = 0; c < getGridSize(); c++)
            {

                //INITIALIZING THE NEW BUTTONS(VISUALIZATION OF FIELDS)
                t[r][c] = new JButton("");
                t[r][c].setBackground(Color.LIGHT_GRAY);
                t[r][c].putClientProperty("r", r);
                t[r][c].putClientProperty("c", c);
                //CREATING THE ACTION LISTENER FOR LMB CLICKS
                t[r][c].addMouseListener(new MouseClickListener());
                getMyPanel().add(t[r][c]);          //HAPPENS ON EVERY BUTTON, ADDS THE BUTTON TO THE PANEL
            }
        }
    }
    public static void flagging(int r, int c){
        field[r][c].setFlagged(true);
        t[r][c].setBackground(Color.PINK);
    }
    public static void setVaccineInField(){
        for(int vaccine : vaccines){
            c=0;
            r=0;
            c = vaccine % getGridSize();
            r = (vaccine - c) / getGridSize();
            field[r][c].setVaccine(true);
        }
    }
    public static void randomizeBomb(){
        Random rand = new Random();
        int upperLimit = getGridSize()*getGridSize();
        for (int a = 0; a < bombs.length; a++) {
            bombs[a] = rand.nextInt(upperLimit);

            for (int b = 0; b < a; b++) {
                if (bombs[a] == bombs[b]) {
                    a--;
                    break;
                }
            }
        }

    }
    public static void randomizeVaccine(){
        Random rand = new Random();
        int upperLimit = getGridSize()*getGridSize();
        for (int a = 0; a < vaccines.length; a++) {
            vaccines[a] = rand.nextInt(upperLimit);

            for (int b = 0; b < a; b++) {
                if (vaccines[a] == vaccines[b]) {
                    a--;
                    break;
                }

            }
            for (int bomb : bombs) {
                if (vaccines[a] == bomb) {
                    a--;
                    break;
                }
            }
        }
    }
    public static void randomizeFacemask(){
        Random rand = new Random();
        int upperLimit = getGridSize()*getGridSize();
        for (int a = 0; a < facemasks.length; a++) {
            facemasks[a] = rand.nextInt(upperLimit);

            for (int b = 0; b < a; b++) {
                if (facemasks[a] == facemasks[b]) {
                    a--;
                    break;
                }

            }
            for (int bomb : bombs) {
                if (facemasks[a] == bomb) {
                    a--;
                    break;
                }
            }
        }
    }
    public static void assignBombInField(){
        for (int bomb : bombs) {
            c = 0;
            r = 0;
            c = bomb % getGridSize();
            r = (bomb - c) / getGridSize();
            field[r][c].setValue(9);
            field[r][c].setChecked(true);
        }

    }
    public static void setFacemaskInField(){
        for(int facemask : facemasks){
            c=0;
            r=0;
            c = facemask % getGridSize();
            r = (facemask - c) / getGridSize();
            field[r][c].setFacemask(true);
        }

    }
    public static void unflagging(int r, int c){
        field[r][c].setFlagged(false);
        t[r][c].setBackground(Color.LIGHT_GRAY);
    }
    //CALL WHEN A FACEMASK GETS DISCOVERED
    public static void facemaskClicked(int r, int c){
        field[r][c].setFacemask(false);
        JOptionPane.showMessageDialog(null, "You just found a facemask! One COVID particle will be revealed!");
        int toReveal;
        Random rand = new Random();

        for (int a = 0; a < bombs.length; a++) {
            toReveal = rand.nextInt(bombs.length);
            c = bombs[toReveal] % getGridSize();
            r = (bombs[toReveal] - c) / getGridSize();
            if(field[r][c].isFlagged()){
                a--;
            }
            else{
                flagging(r,c);
            }
            break;
        }

    }
    //CALL WHEN A VACCINE GETS DISCOVERED
    public static void vaccineClicked(int r, int c){
        field[r][c].setVaccine(false);
        game.setVaccineCount(game.getVaccineCount()+1);
        JOptionPane.showMessageDialog(null, "You just found a vaccine! You will be saved from one COVID particle!");
        if(game.getVaccineCount() >1){
            JOptionPane.showMessageDialog(null, "Currently you have " + game.getVaccineCount() + " vaccines!");

        }
        else{
            JOptionPane.showMessageDialog(null, "Currently you have " + game.getVaccineCount() + " vaccine!");

        }

    }
    //CHECK FOR VACCINES
    public static void vaccineCheck(int r, int c){
        if(field[r][c].isVaccine()){
            vaccineClicked(r, c);
        }
    }
    //CHECK FOR FACEMASKS
    public static void facemaskCheck(int r, int c){
        if(field[r][c].isFacemask()){
            facemaskClicked(r, c);
        }
    }
    //APP STARTING FUNCTION, IF PASSED TRUE, RESTART FUNCTION
    public static void initialize(boolean reinit){

        titleLabel = new JLabel("The aim of the game:");
        Font boldFont = new Font("Courier", Font.BOLD,16);
        titleLabel.setFont(boldFont);
        textLabel = new JLabel("<html>The objective is to avoid covid particles in the grid."+
                                        "Click any field in the grid <br>and you get the number of COVID particles around the field you clicked.<br>" +
                                        "That might sound like a basic minesweeper game but there's a few twists.<br>" +
                                        "Throughout the field there's a chance you find face masks or vaccines,<br> which we know help us in the fight against COVID. " +
                                        "If you find a vaccine,<br> you get an extra life, meaning when you encounter a COVID particle you <br>stay alive, and the COVID particle gets quarantined." +
                                        "When you find a face <br> mask, a random COVID particle gets revealed on the field." +
                                        "You get 5 points <br>for every field you click, that isn't a COVID particle." +
                                        "Sadly though, <br>as the fight against COVID is also a fight against time,  you lose a point <br>for every ten seconds you spend playing the game." +
                                        "If you end the game <br>with unused vaccines, you get 50 points for each." +
                                        "If you encounter <br>a COVID particle you lose all your points and the game ends.<br>" +
                                        "Write your name into the text box, pick the grid size, <br>or leave it as it is and click play. Good Luck and Have Fun</html>");
        nameLabel = new JLabel("Input your name here");
        nameField = new JTextField();

        //CREATING THE FRAME
        getMyFrame().setSize(485, 460);
        getMyFrame().setVisible(true);
        getMyFrame().setLocationRelativeTo(null);
        getMyFrame().setResizable(true);
        getMyFrame().setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //CREATING THE PANEL AND THE RADIO BUTTONS
        getMyPanel().setVisible(true);
        getMyFrame().add(getMyPanel());
        getSmallGrid().setVisible(true);
        getBigGrid().setVisible(true);
        getStartButton().setVisible(true);
        //ADDING EVERYTHING TO THE PANEL
        getMyPanel().setLayout(null);
        getMyPanel().add(nameField);
        getMyPanel().add(nameLabel);
        getMyPanel().add(titleLabel);
        getMyPanel().add(textLabel);
        getMyPanel().add(getSmallGrid());
        getMyPanel().add(getBigGrid());
        getMyPanel().add(getStartButton());
        //ADDING THE ACTION LISTENER TO THE START BUTTON
        if(!reinit){
            getStartButton().addActionListener(e -> startButtonClicked()
        );}
        else{
            getMyPanel().setLayout(new BorderLayout());

        }
        //ADDING RADIO BUTTONS THE THE BUTTON GROUP
        G1.add(getSmallGrid());
        G1.add(getBigGrid());
        getSmallGrid().setSelected(true);               //DEFAULTS THE 10X10 GRID
        titleLabel.setBounds(20, 20, 600, 20);
        textLabel.setBounds(20, -30, 600, 400);
        nameField.setBounds(200,330,200,20);
        nameLabel.setBounds(20,330,180,20);
        getSmallGrid().setBounds(20,300,180,20);
        getBigGrid().setBounds(200,300,200,20);
        getStartButton().setBounds(200,360,200,50);

    }
    //IF THE CLICKED FIELD DOESN'T HAVE BOMBS AROUND IT, CLEAR FIELDS AROUND THE CLICKED FIELD
    public static void revealZero(int r, int c){
        facemaskCheck(r, c);
        vaccineCheck(r, c);
        field[r][c].setCovered(false);
        if(field[r][c].getValue() == 0){
            revealNeighboring(r,c);}

        switch (field[r][c].getValue()) {
            case 0:
                t[r][c].setText(".");

                break;
            default:
                t[r][c].setText(Integer.toString(field[r][c].getValue()));

                break;
        }
        getT(r, c).setBackground(Color.WHITE);
    }
    //CLEARS FIELDS AROUND PASSED COORDINATE FIELD
    public static void revealNeighboring(int r, int c){
        if(r!=0){
            if(field[r-1][c].isCovered()){
                revealZero(r-1, c);
                field[r-1][c].setCovered(false);
            }
        }
        if(c!=0){
            if(field[r][c-1].isCovered()){
                revealZero(r, c-1);
                field[r][c-1].setCovered(false);
            }
        }
        if(r != (getGridSize()-1)){
            if(field[r+1][c].isCovered()){
                revealZero(r+1, c);
                field[r+1][c].setCovered(false);
            }
        }
        if(c != (getGridSize()-1)){
            if(field[r][c+1].isCovered()){
                revealZero(r, c+1);
                field[r][c+1].setCovered(false);
            }
        }
        if(r!= 0 && c!=0){
            if(field[r-1][c-1].isCovered()){
                revealZero(r-1, c-1);
                field[r-1][c-1].setCovered(false);
            }
        }
        if(r!= 0 && c != (getGridSize()-1)){
            if(field[r-1][c+1].isCovered()){
                revealZero(r-1, c+1);
                field[r-1][c+1].setCovered(false);
            }
        }
        if(r != (getGridSize()-1) && c != (getGridSize()-1)){
            if(field[r+1][c+1].isCovered()){
                revealZero(r+1, c+1);
                field[r+1][c+1].setCovered(false);
            }
        }
        if(r != (getGridSize()-1) && c != 0){
            if(field[r+1][c-1].isCovered()){
                revealZero(r+1, c-1);
                field[r+1][c-1].setCovered(false);
            }
        }
    }
    //GAME STARTING BUTTON LISTENER
    public static void startButtonClicked(){

        Game.setName(nameField.getText());
        if(getSmallGrid().isSelected()){
            setGridSize(10);
        }
        else if (getBigGrid().isSelected()){
            setGridSize(20);
        }
        else{
            setGridSize(10);
        }
        getMyPanel().setLayout(new GridLayout(getGridSize(), getGridSize()));             //SETTING THE LAYOUT OF THE PANEL TO A GRID, THE SIZE IS DETERMINED BY THE STARTING CHOICE
        //REMOVING THE BUTTONS, SO IT DOESN'T INTERFERE WITH THE GRID LAYOUT
        getMyPanel().remove(getSmallGrid());
        getMyPanel().remove(getBigGrid());
        getMyPanel().remove(getStartButton());
        getMyPanel().remove(titleLabel);
        getMyPanel().remove(textLabel);
        getMyPanel().remove(nameLabel);
        getMyPanel().remove(nameField);


        t = new JButton[getGridSize()][getGridSize()];
        generateField();
        getMyFrame().pack();
        tenSecCounterInt = 0;
        getMyFrame().setSize(50*getGridSize(),50*getGridSize());            //SETTING THE PANEL SIZE, TO BE 30 PIXELS FOR EVERY FIELD
        JOptionPane.showMessageDialog(null, "The timer will start when you click OK, hurry up, because you have a war to win against COVID.");
        TimerTask tenSecCounter = new TimerTask() {
            @Override

            public void run() {
                tenSecCounterInt +=1;
                getMyFrame().setTitle("1903519 -Vaccines:"+ game.getVaccineCount()+ "-Minus points gathered from passing time: " + tenSecCounterInt);

            }
        };
        Timer timer;
        timer = new Timer( );
        timer.schedule(tenSecCounter, 10000,10000);
    }
}

class Game{
    public static String getName() {
        return name;
    }

    public int getVaccineCount() {
        return vaccineCount;
    }
    public static int getScore() {
        return score;
    }

    public void setVaccineCount(int vaccineCount) {
        this.vaccineCount = vaccineCount;
    }
    public static void setScore(int score) {
        Game.score = score;
    }

    private int vaccineCount;       //VARIABLE MAINLY USED FOR ASSIGNING 50 POINTS PER EVERY VACCINE YOU END THE GAME WITH
    private static int score;
    private static int scoresetter;
    Game(){
        vaccineCount = 0;
        score = 0;
    }

    public static void setName(String name) {
        Game.name = name;
    }

    private static String name;

    //CHECKS IF THE GAME HAS ENDED
    public static void checkGameEnd(){
        int count = 0;
        //COUNTS THE COVERED FIELDS, IF THE NUMBER OF COVERED FIELDS IS EQUAL TO THE NUMBER OF BOMBS, THE GAME HAS ENDED, THE PLAYER WON THE GAME
        for(CE203_1903519_Ass2.r = 0; CE203_1903519_Ass2.r < CE203_1903519_Ass2.getGridSize(); CE203_1903519_Ass2.r++) {
            for(CE203_1903519_Ass2.c = 0; CE203_1903519_Ass2.c < CE203_1903519_Ass2.getGridSize(); CE203_1903519_Ass2.c++)
            {
                if(CE203_1903519_Ass2.getField(CE203_1903519_Ass2.r, CE203_1903519_Ass2.c).isCovered()){
                    count++;
                }
            }
        }
        if(count == CE203_1903519_Ass2.getBombs().length){
            endGame(true);
        }
    }
    public static void endGame(boolean won) {



        if(won){
            //CALCULATING FINAL SCORE + 5 FOR EVERY UNCOVERED FIELD + 50 FOR EVERY VACCINE - 1 FOR EVERY TEN SECONDS PASSED
            scoresetter = CE203_1903519_Ass2.getGridSize()*CE203_1903519_Ass2.getGridSize() - CE203_1903519_Ass2.getBombs().length;
            scoresetter *= 5;
            scoresetter -= CE203_1903519_Ass2.getTenSecCounterInt();
            scoresetter += 50*CE203_1903519_Ass2.getGame().getVaccineCount();
            setScore(scoresetter);
            JOptionPane.showMessageDialog(null, "You won, your score was " + getScore()+". To see the top Five scores of all time click OK");
            writeIf();
            readScore();
        }
        else{


                JOptionPane.showMessageDialog(null, "You lost, Click OK, or close this message to restart the game.");

            //REMOVES THE BUTTONS USED PREVIOUSLY

            readScore();
        }
    }
    static ArrayList<String> lines = new ArrayList();                     //DECLARING ARRAYLIST

    public static void readScore(){

        File scoreFile = new File("filename.txt");
        String[] columns = {"Name", "Score", "Grid"};
        JTable table;
        JDialog jd = new JDialog(CE203_1903519_Ass2.getMyFrame());
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        model.setRowCount(0);
        lines.clear();
        try{
            Scanner sc = new Scanner(scoreFile);
            while(sc.hasNextLine()){
                lines.add(sc.nextLine());
            }
            sc.close();
            model.setRowCount(0);
            for (String line : lines) {
                String[] splitted = line.split(";");
                model.addRow(splitted);
            }

            table = new JTable();
            table.setModel(model);

            table.setBounds(100,100,200,200);
            jd.setVisible(true);
            jd.setLocationRelativeTo(null);
            jd.setSize(330,330);
            jd.setLayout(null);
            jd.setTitle("Top 5 scores");
            JScrollPane mySp = new JScrollPane(table);
            jd.add(mySp);
            mySp.setBounds(10,10,300,200);
            JButton nextGame = new JButton("Restart Game");

            nextGame.addActionListener(e -> {
                restartGame();
            });

            jd.add(nextGame);
            nextGame.setVisible(true);
            nextGame.setBounds(10,230,300,30);

        }catch(FileNotFoundException e){
            JOptionPane.showMessageDialog(null, "There was a problem reading the file");
        }
    }

    public static void restartGame(){
        for( CE203_1903519_Ass2.r = 0; CE203_1903519_Ass2.r < CE203_1903519_Ass2.getGridSize(); CE203_1903519_Ass2.r++) {
            for( CE203_1903519_Ass2.c = 0; CE203_1903519_Ass2.c < CE203_1903519_Ass2.getGridSize(); CE203_1903519_Ass2.c++)
            {
                CE203_1903519_Ass2.getMyPanel().remove(CE203_1903519_Ass2.getT(CE203_1903519_Ass2.r, CE203_1903519_Ass2.c));
            }
        }
        CE203_1903519_Ass2.getMyFrame().dispose();


        CE203_1903519_Ass2.initialize(true);
    }
    public static void writeIf(){
        try{
            File scoreFile = new File("filename.txt");
            Scanner sc = new Scanner(scoreFile);
            while(sc.hasNextLine()){
                lines.add(sc.nextLine());
            }
            sc.close();
            ArrayList<Integer> scores = new ArrayList<Integer>();
            for (String line : lines) {
                String[] splitted = line.split(";");
                scores.add(Integer.parseInt(splitted[1]));

            }
            FileWriter scoreWriter = new FileWriter(scoreFile);
            JOptionPane.showMessageDialog(null, lines.size());
            if(lines.size()<5){
                scoreWriter.write(Game.getName()+ ";" + scoresetter + ";" + CE203_1903519_Ass2.getGridSize()+"\n");
            }
            for(int i = 0; i<scores.size(); i++){
                if(scoresetter> scores.get(i)){
                    for(int z = 0; z< scores.size(); z++){
                        if(z == i){
                            scoreWriter.write(Game.getName()+ ";" + scoresetter + ";" + CE203_1903519_Ass2.getGridSize()+"\n");

                        }
                        else {
                            scoreWriter.write(lines.get(i));
                        }
                        }


                    }
            }
            scoreWriter.close();
        }
        catch(IOException e){
            JOptionPane.showMessageDialog(null, "Error opening file");
        }
    }
}

class Field{
    //GETTERS
    public int getValue() {
        return value;
    }
    public boolean isFlagged() {
        return flagged;
    }
    public boolean isCovered() {
        return covered;
    }
    public boolean isChecked() {
        return checked;
    }
    public boolean isFacemask() {
        return facemask;
    }
    public boolean isVaccine() {
        return vaccine;
    }

    //SETTERS
    public void setChecked(boolean c) {
        this.checked = c;
    }
    public void setValue(int v) {
        this.value = v;
    }
    public void setCovered(boolean covered) {
        this.covered = covered;
    }
    public void setFlagged(boolean flagged) {
        this.flagged = flagged;
    }
    public void setFacemask(boolean facemask) {
        this.facemask = facemask;
    }
    public void setVaccine(boolean vaccine) {
        this.vaccine = vaccine;
    }

    //DECLARATIONS
    private int value;
    private boolean covered;
    private boolean checked;
    private boolean flagged;
    private boolean vaccine;
    private boolean facemask;

    //CONSTRUCTOR
    Field(){
        covered = true;
        value = 0;
        checked = false;
        flagged = false;
        vaccine = false;
        facemask = false;
    }
}

class KeyboardListener implements KeyListener{

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
}

class MouseClickListener implements MouseListener {

    @Override
    public void mouseClicked(MouseEvent e) {

        //CHECKS IF THE CLICK WAS A RIGHT CLICK

        if(e.getButton() == MouseEvent.BUTTON3) {
            //LOOPING THROUGH EVERY FIELD IN EVERY ROW
            for (int rows = 0; rows < CE203_1903519_Ass2.getGridSize(); rows++) {
                for (int columns = 0; columns < CE203_1903519_Ass2.getGridSize(); columns++) {
                    //CHECKS IF IT IS AT THE BUTTON THAT CALLED THE EVENT
                    if (CE203_1903519_Ass2.getT(rows, columns) == e.getSource()){
                        //IF IT'S ALREADY FLAGGED, UNFLAG IT
                        if(CE203_1903519_Ass2.getField(rows, columns).isFlagged()){
                            CE203_1903519_Ass2.getT(rows, columns).setText("");//REWORK
                            CE203_1903519_Ass2.unflagging(rows,columns);
                            break;
                        }
                        //IF IT'S NOT FLAGGED YET, FLAG IT
                        if(CE203_1903519_Ass2.getField(rows, columns).isCovered())
                        {
                            CE203_1903519_Ass2.getT(rows, columns).setText("Q");//REWORK

                            CE203_1903519_Ass2.flagging(rows, columns);
                            break;
                        }
                    }
                }
            }
        }
        else
            {
        //LOOPING THROUGH EVERY FIELD IN EVERY ROW
        for (int rows = 0; rows < CE203_1903519_Ass2.getGridSize(); rows++) {
            for (int columns = 0; columns < CE203_1903519_Ass2.getGridSize(); columns++) {
                //CHECKS IF IT IS AT THE BUTTON THAT CALLED THE EVENT
                if (CE203_1903519_Ass2.t[rows][columns] == e.getSource()){
                    //CHECKS IF THE CLICKED FIELD IS FLAGGED
                    if(!CE203_1903519_Ass2.getField(rows, columns).isFlagged())
                    {
                        //HAPPENS WHEN A BOMB IS CLICKED
                        if (CE203_1903519_Ass2.getField(rows, columns).getValue() == 9) {
                            if(CE203_1903519_Ass2.getGame().getVaccineCount()>0){
                                JOptionPane.showMessageDialog(null, "You just encountered a COVID particle! You're in luck because you have a vaccine!");
                                CE203_1903519_Ass2.getGame().setVaccineCount(CE203_1903519_Ass2.getGame().getVaccineCount()-1);
                                CE203_1903519_Ass2.flagging(rows,columns);}
                            else{
                                CE203_1903519_Ass2.getT(rows, columns).setText("C"); ///REWRITE
                                CE203_1903519_Ass2.getT(rows, columns).setBackground(Color.WHITE);

                                CE203_1903519_Ass2.getField(rows, columns).setCovered(false);
                                Game.endGame(false);}
                        }
                        //HAPPENS WHEN A FIELD IS CLICKED WHICH HAS NO BOMBS AROUND IT
                        else if (CE203_1903519_Ass2.getField(rows, columns).getValue() == 0) {

                            CE203_1903519_Ass2.revealZero(rows, columns);
                            Game.checkGameEnd();

                        }
                        else
                            {
                            //HAPPENS IN EVERY OTHER CASE, THAT IS WHEN IT HAS A NUMBER OF BOMBS AROUND IT 1-8
                            CE203_1903519_Ass2.getT(rows, columns).setText(Integer.toString(CE203_1903519_Ass2.getField(rows, columns).getValue()));
                            CE203_1903519_Ass2.getT(rows, columns).setBackground(Color.WHITE);
                            CE203_1903519_Ass2.getField(rows, columns).setCovered(false);
                            CE203_1903519_Ass2.vaccineCheck(rows, columns);
                            CE203_1903519_Ass2.facemaskCheck(rows, columns);
                            Game.checkGameEnd();

                            }
                    }
                }

            }

        }
        }

    }
    @Override
    public void mousePressed(MouseEvent e) {

    }
    @Override
    public void mouseReleased(MouseEvent e) {

    }
    @Override
    public void mouseEntered(MouseEvent e) {

    }
    @Override
    public void mouseExited(MouseEvent e) {

    }
}
