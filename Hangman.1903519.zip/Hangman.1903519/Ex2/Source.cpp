#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <vector>
#include "FileRead.h"
#include "Manager.h"
#include "HangMan.h"
#include "Gamer.h"
using namespace std;
int cot = 5;
void Copy2Files(string x, string y)		// inner function to copy one file to another using file handling
{
	ifstream fin;
	ofstream fout;
	string line;
	fout.open(y);
	fin.open(x);
	while (getline(fin, line))
	{
		fout << line << endl;
	}
	fout.close();
	fin.close();
}

void Top10()	// This function is used for displaying top 10 high scorers
{
	ifstream fin;
	ofstream fout;

	string Reg, fileName;
	int S1, S2, S3;
	fin.open("UserNames.txt");
	while (fin >> Reg)
	{
		fin >> fileName;

		if (Reg[0] == 'G')
		{
			fin >> S1 >> S2 >> S3;
		}
	}
	fin.close();
}

void Game()		// This is the The Game menu for the HANGMAN game 
{
	int n = 1;
	string level = "easy";
	int option;
	string name, fileName, Reg;
	int S1 = 0, S2 = 0, S3 = 0;
	int flag = 0;
	while (1)
	{
		system("cls");
		ifstream fin;
		ofstream fout;
		cout << " -- HANG MAN -- " << endl;

		vector<string> NewName;
		cout << " Enter Name: ";
		cin >> name;					/// Asks user for their name
		fin.open("UserNames.txt");
		while (fin >> Reg)
		{
			fin >> fileName;

			if (Reg[0] == 'G')
			{
				fin >> S1 >> S2 >> S3;
			}
			if (name == fileName)
			{
				flag = 1;
				break;
			}

		}
		fin.close();

		if (flag == 0)			// Creates a new Gamer and Saves Them in the File
		{
			ofstream fout;
			int val;
			vector<string> New;
			for (int lp = 0;lp < n; lp++)
			{
				val = 20 + (rand() % 50);
			}
			n++;
			string Newreg = "G" + to_string(val);
			New.push_back(Newreg);
			New.push_back(name);
			New.push_back("0 0 0");
			vector<string>::iterator i = New.begin();
			fout.open("UserNames.txt",ios::app);
			fout << endl;
			while(i != New.end())
			{
				fout << *i << " ";
				i++;
			}
			fout.close();
			cout << " New Gamer Added " << endl << endl;
		}
		else
		{
		}
		if (Reg[0] == 'G')			// Displays Gamers Options 
		{
			while (1)
			{
				cout << " -- Gamer -- " << endl;
				cout << " 1) Play game \n 2) Your Statistics \n 3) Display top 10 \n 4) Exit Game \n";
				cout << " Please enter option number: ";
				cin >> option;
				if (option == 1)
				{
					FileRead fi;
					fi.Read(level);
					int select;
					for (int i = 0; i < n; i++)
					{
						select = 1 + (rand() % cot);
					}
					HangMan x;
					int S=x.HangManStart(level, select);
					Gamer xo(Reg, name, level, S1, S2, S3);
					xo.SaveScore(S);
					xo.SaveScore(S);
				}
				if (option == 2)		// Displays Stats
				{
					float x1=0.0, x2=0.0,x3=0.0;
					int count1=0,count2=0,count3=0;
					fin.open("Scores.txt");
					while (fin >> Reg)
					{
						if(Reg == ",")
						{
							fin >> S1 >> S2 >> S3;
							if (name == fileName)
							{
								if (S1 != 0)
								{
									x1 = x1 + S1;
									count1++;
								}
								if (S2 != 0)
								{
									x2 = x2 + S2;
									count2++;
								}
								if (S3 != 0)
								{
									x3 = x3 + S3;
									count3++;
								}

							}
							
						}
						else
						{		
							fin >> fileName;
							fin >> S1 >> S2 >> S3;
							if (name == fileName)
							{
								if (S1 != 0)
								{
									x1 = x1 + S1;
									count1++;
								}
								if (S2 != 0)
								{
									x2 = x2 + S2;
									count2++;
								}
								if (S3 != 0)
								{
									x3 = x3 + S3;
									count3++;
								}
							}
						}
						

					}
					fin.close();
					cout << " " << name << ", your Average Scores are: \n 1) Easy: " << x1/count1 << " \n 2) Medium: " << x2 / count2 << " \n 3) Hard: " << x3 / count3 << endl << endl;
				}
				if (option == 3)		// Display top 10
				{
					vector <string> ENames;
					vector<string> MNames;
					vector<string> HNames;

					string ename, mname, hname;
					string prevename="", prevmname="", prevhname="";

					int max1=0, max2=0, max3=0;
					int f1 = 0, f2 = 0, f3 = 0;
					int prevMax1 = 10000, prevMax2 = 10000, prevMax3 = 10000;
					for (int i = 0; i < 10; i++)
					{
						fin.open("UserNames.txt");

						while (fin >> Reg)
						{
							fin >> fileName;

							if (Reg[0] == 'G')
							{
								fin >> S1 >> S2 >> S3;
								if ((S1 >= max1) && (S1<prevMax1))
								{
										ename = fileName;
										max1 = S1;
										f1 = 1;
								}
								if ((S2 >= max2) && (S2<prevMax2))
								{
									mname = fileName;
									max2 = S2;
									f2 = 1;

								}
								if ((S3 >= max3) && (S3<prevMax3))
								{
									hname = fileName;
									max3 = S3;
									f3 = 1;

								}

							}

						}

						if (f1 != 0)
						{
							ENames.push_back(ename);
							ENames.push_back(to_string(max1));
						}
						if (f2 != 0)
						{
							MNames.push_back(mname);
							MNames.push_back(to_string(max2));
						}
						
						if (f3 != 0)
						{
							HNames.push_back(hname);
							HNames.push_back(to_string(max3));
						}
						f1 = 0, f2 = 0, f3 = 0;

						

						fin.close();
						prevMax1 = max1;
						prevename = ename;
						prevMax2 = max2;
						prevmname = mname;
						prevMax3 = max3;
						prevhname = hname;


						max1 = 0, max2 = 0, max3 = 0;

						

					}
					vector<string>::iterator i = ENames.begin();
					int flag = 0;
					cout << endl << endl <<" Top 10 (Easy): " << endl;
					while (i != ENames.end())
					{
						cout << " " << flag+1 <<": "<< *i;
						if (name == *i)
						{
							cout << "(YOU)";
						}
						i++;
						cout << "   " << *i << endl;
						i++;
						flag++;
					}
					cout << endl << endl <<" Top 10 (Medium): " << endl;
					i = MNames.begin();
					flag = 0;
					while (i != MNames.end())
					{
						cout << " " << flag + 1 << ": " << *i;
						if (name == *i)
						{
							cout << "(YOU)";
						}
						i++;
						cout << "   " << *i << endl;
						i++;
						flag++;
					}
					cout<< endl << endl << " Top 10 (Hard): "<< endl;
					i = HNames.begin();
					flag = 0;
					while (i != HNames.end())
					{
						cout << " " << flag + 1 << ": " << *i;
						if (name == *i)
						{
							cout << "(YOU)";
						}
						i++;
						cout << "   " << *i << endl;
						i++;
						flag++;
					}
					cout << endl << endl;

				}
				if (option == 4)
				{
					return;
				}
			}

		}
		if (Reg[0] == 'M')
		{
			Manager xo(Reg,name);		// Here The mamanger options are displayed if the Registeration number is for managers
			while (1)
			{
				cout << " -- Manager --" << endl;
				cout << " 1) Reset game \n 2) Change game levels \n 3) Add another manager \n 4) Set the word file \n 5) Exit Game \n";
				cout << " Please enter option number: ";
				cin >> option;
				if (option == 1)
				{
					break;
				}
				if (option == 2)		// Changing Difficulty Level
				{
					cout << " 1) Easy \n 2) Medium \n 3) Hard \n";
					cout << " Please enter option number: ";
					cin >> option;
					if (option == 1)
					{
						level = "easy";
					}
					else if (option == 2)
					{
						level = "medium";
					}
					else if (option == 3)
					{
						level = "hard";
					}
				}
				if (option == 3)			// Adding new Managers
				{
					cout << " Enter the New Manager Name: ";
					string newName;
					cin >>newName;
					ofstream fout;
					int val;
					vector<string> New2;
					for (int lp = 0;lp < n; lp++)
					{
						val = 30 + (rand() % 50);
					}
					n++;
					string Newreg = "M" + to_string(val);
					New2.push_back(Newreg);
					New2.push_back(newName);

					vector<string>::iterator i = New2.begin();
					fout.open("UserNames.txt", ios::app);
					fout << endl;
					while (i != New2.end())
					{
						cout << *i << " New Manager Added";
						fout << *i << " ";
						i++;
					}
					fout.close();
					cout << endl << endl;
				}
				if (option == 4)		// Add words or delete the word file
				{
					string ww;
					cout << " 1) Erase the whole word file \n 2) enter a word in the word file: "<< endl;
					cin >> option;
					if (option == 1)
					{
						fout.open("words.txt");
						fout << " ";
						fout.close();

					}
					if (option == 2)		
					{
						while (1)
						{
							cout << " Enter a word or Enter -1 to return: ";
							cin >> ww;
							if (ww == "-1")
							{
								break;
							}
							else
							{
								fout.open("words.txt", ios::app);
								fout << endl << ww;
								cot++;
								fout.close();
								cout << " Enter the word " << ww << "'s phrase: ";
								string ans;
								cin.ignore();
								getline(cin,ans);
								fout.open("phrases.txt", ios::app);
								fout<<endl<<ans;
								fout.close();
							}

						}
						cout << endl;

					}
					
				}
				if (option == 5)		// Exit function
				{
					return;
				}
			}

		}

	}
}


int main()
{
	Game();

}