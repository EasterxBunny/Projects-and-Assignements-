#pragma once
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

class HangMan
{
private:
	string difficulty,word,misses,wordf,phrase;
	int guess,correct,score,mistakes,select;
public:
	void WordSelection(int s);
	int HangManStart(string difficulty,int s);
	int Game();
	void DisplayHangMan(char s);
};


int HangMan::HangManStart(string x, int s)			// Start of the game that sets variables as well
{
	difficulty = x;
	correct = 0;
	misses="";
	mistakes = 0;
	score = 0;
	wordf = "";
	WordSelection(s);
	for (int i = 0; i < guess; i++)
	{
		wordf = wordf + "_";
	}
	cout << endl;
	return Game();
	
}

int HangMan::Game()		// The Game function runs the game until all the guess words are correct or there are more than 6 mistakes
{
	char l;
	int lo = 0;
	int prev = guess,dcheck = 0;
	int flag = 0;
	int ii = 0;
	while (ii < phrase.length())
	{
		if (phrase[ii] == 'X')
		{
			break;
		}
		ii++;
	}
	while (1)
	{
		if (guess == correct || mistakes==6)
		{
			if (correct == guess)		// Displays winning or loosing
			{
				cout << " Congrats! You WON..."<< endl;
			}
			else
			{
				cout << " Unlucky! You LOST..." << endl;
			}
			cout << " The Word was: " << word << endl;
			cout << " Your Final Score: " << score << endl;
			
			cout << endl << endl;
			return score;

		}
		else
		{
			cout << " Enter a Letter: ";
			cin >> l;
			for (int i = 0; i < guess; i++)		// Checks correction
			{
				if (word[i] == l)
				{
					wordf[i] = l;
					for (int d = 0; d < guess; d++)
					{
						if (wordf[d] == '_')
						{
							dcheck++;
						}
					}
					if (dcheck < prev)
					{
						prev = dcheck;
						correct++;
					}
					dcheck = 0;
					flag = 1;
					score = score + 5;
					phrase[ii + i] = l;

				}
			}
			if (flag == 0)
			{
				mistakes++;
				misses = misses + l+',';
			}
			flag = 0;
			system("cls");
			DisplayHangMan(l);
		}
	}
}

void HangMan::DisplayHangMan(char s)		// Displays the hangman and the hints and words
{
	if (mistakes == 0)
	{
		cout << "  |---|	"<< "\n      |	"<<"\n      | " << "\n      | \n    _/-\\_" << endl << endl;

	}
	if (mistakes == 1)
	{
		cout << "  |---|	"<< "\n  O   |	" << "\n      |	"<< "\n      | \n    _/-\\_" << endl << endl;
	}
	if (mistakes == 2)
	{
		cout << "  |---|	"<< "\n  O   |	" << "\n  |   |	"<< "\n      | \n    _/-\\_" << endl << endl;
	}
	if (mistakes == 3)
	{
		cout << "  |---|	"<< "\n  O   |	" << "\n /|   |	" << "\n      | \n    _/-\\_" << endl << endl;
	}
	if (mistakes == 4)
	{
		cout << "  |---|	"<< "\n  O   |	" << "\n /|\\  | " << "\n      | \n    _/-\\_" << endl << endl;

	}
	if (mistakes == 5)
	{
		cout << "  |---|	"<<"\n  O   |	" << "\n /|\\  | " << "\n /    | \n    _/-\\_" << endl << endl;

	}
	if (mistakes == 6)
	{
		cout << "  |---|	"<< "\n  O   |	 " << "\n /|\\  | " << "\n / \\  | \n    _/-\\_" << endl << endl;

	}

	cout << endl <<" HINT: "<< phrase  << endl;
	cout << " Mistakes: "<< misses << endl;
	cout << " Letter: " << s << endl;

	
}

void HangMan::WordSelection(int s)			// Selects the word on random from the file
{
	select = s;
	ifstream fin;
	string x;

	int flag = 0;
	int n, m;
	if (difficulty == "easy")
	{
		m = 1;
		n = 5;
	}
	else if (difficulty == "medium")
	{
		m = 6;
		n = 10;
	}
	else
	{
		m = 10;
		n = 100;
	}
	int no = 0;
	fin.open("words.txt");
	while (flag <= select)
	{
		while (fin >> x)
		{
			no++;
			if (x.length() <= n && x.length() >= m)
			{
				flag++;
				break;
			}
		}
	}
	fin.close();
	fin.open("phrase.txt");
	for (int i = 0;i < no; i++)
	{
		getline(fin, phrase);
	}
	fin.close();
	guess = x.length();
	word = x;
}