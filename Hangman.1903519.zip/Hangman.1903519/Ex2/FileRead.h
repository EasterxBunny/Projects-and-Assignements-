#pragma once
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

class FileRead
{
private:
public:
	void ClearingFile()		// This Is used to ease the previous set Data and make space for the new one
	{
		ofstream fout;
		fout.open("phrase.txt");
		fout << " ";
		fout.close();
		fout.open("words.txt");
		fout << " ";
		fout.close();
		fout.open("lines.txt");
		fout << " ";
		fout.close();
	}
	void Read(string level)		// Read data from the book.txt and save the words on the base of their size set by Difficulty Levels
	{
		int n = 0;
		int m = 0;
		if (level == "easy")
		{
			m = 1;
			n = 5;
		}
		else if (level == "medium")
		{
			m = 6;
			n = 10;
		}
		else if (level == "hard")
		{
			m = 10;
			n = 100;
		}
		ifstream fin;
		ofstream fout;
		string x;
		string phrase = "", wor = "", st = "";
		int l = 0;
		ClearingFile();
		fin.open("book.txt");
		while (fin >> x)			// Sets the phrases and words and save them in files
		{
			for (int i = 0; i < x.length(); i++)
			{
				if (x[i] == '.' || x[i] == '?' || x[i] == ',' || x[i] == '!')
				{
					wor = wor + '.';
					fout.open("lines.txt", ios::app);
					fout << phrase << " ." << endl;
					fout.close();
					int d = 0, secLen = 0;
					st = phrase;
					while (d < phrase.length())
					{
						if (phrase[d] == ' ')
						{
							fout.open("phrase.txt", ios::app);
							if (st[d] >= m && st[d] <= n && st[d] != ',' && st[d] != '.' && st[d] != '?' && st[d] != '!')
							{
								if (st[d] == '.' || st[d] == '?' || st[d] == ',' || st[d] == '!')
								{
									st[d] = '\0';

								}
							}
							if (secLen >= m && secLen <= n)
							{
								fout << st << endl;
							}
							fout.close();
							st = "";
							st = phrase;
							secLen = 0;

						}
						else
						{
							st[d] = 'X';
							secLen++;
						}
						d++;
					}
					phrase = "";
				}
				else
				{
					char low = tolower(x[i]);
					phrase = phrase + low;
				}
				char low = tolower(x[i]);
				x[i] = low;
			}
			if (phrase != "")
			{
				phrase = phrase + " ";

			}
			if (x.length() >= m && x.length() <= n && x != "," && x != "." && x != "?" && x != "!")
			{
				if (x[x.length() - 1] == '.' || x[x.length() - 1] == '?' || x[x.length() - 1] == ',' || x[x.length() - 1] == '!')
				{
					x[x.length() - 1] = '\0';

				}
				fout.open("words.txt", ios::app);
				fout << x << endl;
				fout.close();
			}

		}

		fin.close();
	}
};