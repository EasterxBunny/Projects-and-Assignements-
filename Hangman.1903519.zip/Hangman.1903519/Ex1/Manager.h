#pragma once
#include <iostream>
using namespace std;

class Manager
{
	string Reg;
	string name;
public:
	Manager(string R, string Name)
	{
		Reg = R;
		name=Name;
	}
};