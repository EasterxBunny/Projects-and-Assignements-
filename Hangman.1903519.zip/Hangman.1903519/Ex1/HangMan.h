#pragma once
#include <iostream>
#include <fstream>

using namespace std;

class HangMan
{
private:
	string difficulty,word,misses,wordf;
	int guess,correct,score,mistakes,select;
public:
	void WordSelection(int s);
	int HangManStart(string difficulty,int s);
	int Game();
	void DisplayHangMan(char s);
};


int HangMan::HangManStart(string x, int s)
{
	difficulty = x;
	correct = 0;
	misses="";
	mistakes = 0;
	score = 0;
	wordf = "";
	WordSelection(s);
	for (int i = 0; i < guess; i++)
	{
		wordf = wordf + "_";
	}
	return Game();
	
}

int HangMan::Game()
{
	char l;

	int prev = guess,dcheck = 0;
	int flag = 0;
	while (1)
	{
		if (guess == correct || mistakes==6)
		{
			cout << " The Word was: " << word << endl;
			cout << " Your Final Score: " << score << endl;
			return score;
		}
		else
		{
			cout << " Enter a Letter: ";
			cin >> l;
			for (int i = 0; i < guess; i++)
			{
				if (word[i] == l)
				{
					wordf[i] = l;
					for (int d = 0; d < guess; d++)
					{
						if (wordf[d] == '_')
						{
							dcheck++;
						}
					}
					if (dcheck < prev)
					{
						prev = dcheck;
						correct++;
					}
					dcheck = 0;
					flag = 1;
					score = score + 5;
				}
			}
			if (flag == 0)
			{
				mistakes++;
				misses = misses + l+',';
			}
			flag = 0;
			system("cls");
			DisplayHangMan(l);
		}
	}
}

void HangMan::DisplayHangMan(char s)
{
	if (mistakes == 0)
	{
		cout << "  |---|	Word: " << wordf << "\n      |	Misses: "<< misses <<"\n      |	Guess: " << s<< "\n      | \n    _/-\\_" << endl << endl;

	}
	if (mistakes == 1)
	{
		cout << "  |---|	Word: " << wordf << "\n  O   |	Misses: " << misses << "\n      |	Guess: " << s << "\n      | \n    _/-\\" << endl << endl;
	}
	if (mistakes == 2)
	{
		cout << "  |---|	Word: " << wordf << "\n  O   |	Misses: " << misses << "\n  |   |	Guess: " << s << "\n      | \n    _/-\\_" << endl << endl;
	}
	if (mistakes == 3)
	{
		cout << "  |---|	Word: " << wordf << "\n  O   |	Misses: " << misses << "\n /|   |	Guess: " << s << "\n      | \n    _/-\\_" << endl << endl;
	}
	if (mistakes == 4)
	{
		cout << "  |---|	Word: " << wordf << "\n  O   |	Misses: " << misses << "\n /|\\  |	Guess: " << s << "\n      | \n    _/-\\_" << endl << endl;

	}
	if (mistakes == 5)
	{
		cout << "  |---|	Word: " << wordf << "\n  O   |	Misses: " << misses << "\n /|\\  |	Guess: " << s << "\n /    | \n    _/-\\_" << endl << endl;

	}
	if (mistakes == 6)
	{
		cout << "  |---|	Word: " << wordf << "\n  O   |	Misses: " << misses << "\n /|\\  |	Guess: " << s << "\n / \\  | \n    _/-\\_" << endl << endl;

	}
	
}

void HangMan::WordSelection(int s)
{
	select = s;
	ifstream fin;
	string x;

	int flag = 0;
	int n, m;
	if (difficulty == "easy")
	{
		m = 1;
		n = 5;
	}
	else if (difficulty == "medium")
	{
		m = 6;
		n = 10;
	}
	else
	{
		m = 10;
		n = 100;
	}
	fin.open("words.txt");
	while (flag <= select)
	{
		while (fin >> x)
		{
			if (x.length() <= n && x.length() >= m)
			{
				flag++;
				break;
			}

		}
	}
	guess = x.length();
	word = x;
}