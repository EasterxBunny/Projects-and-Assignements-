#pragma once
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

class Gamer
{
	string Reg;
	string name;
	string level;
	int S1, S2, S3;
public:
	Gamer(string R,string N,string l,int Sc1,int Sc2,int Sc3)
	{
		Reg=R;
		name=N;
		level=l;
		S1=Sc1, S2=Sc2, S3=Sc3;
	}

	void Copy2Files(string x, string y)
	{
		ifstream fin;
		ofstream fout;
		string line;
		fout.open(y);
		fin.open(x);
		while (getline(fin, line))
		{
			fout << line << endl;
		}
		fout.close();
		fin.close();
	}

	void UpdateScore(int S)
	{
		ifstream fin;
		ofstream fout;
		int flag2 = 0;

		if (level == "easy")
		{
			if (S > S1)
			{
				flag2 = 1;
			}
		}
		if (level == "medium")
		{
			if (S > S2)
			{
				flag2 = 2;

			}
		}
		if (level == "hard")
		{
			if (S > S3)
			{
				flag2 = 3;

			}
		}
		if (flag2 != 0)
		{
			string fileName, Reg;
			fin.open("UserNames.txt");
			fout.open("UserNames2.txt");
			while (fin >> Reg)
			{
				fout << Reg << " ";
				fin >> fileName;
				fout << fileName << " ";
				if (Reg[0] == 'G')
				{
					fin >> S1 >> S2 >> S3;
					if (fileName == name)
					{
						if (flag2 == 1)
						{
							fout << S << " " << S2 << " " << S3 << " ";
						}
						else if (flag2 == 2)
						{
							fout << S1 << " " << S << " " << S3 << " ";
						}
						else if (flag2 == 3)
						{
							fout << S1 << " " << S2 << " " << S << " ";
						}
					}
					else
					{
						fout << S1 << " " << S2 << " " << S3 << " ";
					}
					fout << endl;

				}


			}
			flag2 = 0;
			fin.close();
			fout.close();
			Copy2Files("UserNames2.txt", "UserNames.txt");
		}

	}


	void SaveScore(int S)
	{
		int flag2 = 0;
		int flag4 = 0;
		ifstream fin;
		ofstream fout;
		string Reg, fileName;
		int loop = 0;
		fin.open("Scores.txt");
		fout.open("Scores2.txt");
		while (fin >> Reg)
		{
			if (Reg == ",")
			{
				fin >> S1 >> S2 >> S3;
				fout << ", " << S1 << " " << S2 << " " << S3 << " ";
				if (name == fileName)
				{
				}

			}
			else
			{
				if (loop != 0)
				{
					fout << endl;
				}
				loop++;
				fin >> fileName;
				fout << Reg << " " << fileName << " ";
				if (name == fileName)
				{
					if (level == "easy")
					{
						fout << S << " " << 0 << " " << 0 << " , ";

					}
					else if (level == "medium")
					{
						fout << 0 << " " << S << " " << 0 << " , ";

					}
					else if (level == "hard")
					{
						fout << 0 << " " << 0 << " " << S << " , ";
					}
					flag4 = 1;
				}
				fin >> S1 >> S2 >> S3;
				fout << S1 << " " << S2 << " " << S3 << " ";

			}
		}
		cout << " Score Saved! " << endl;
		fin.close();
		fout.close();
		if (flag4 == 0)
		{
			fout.open("Scores2.txt", ios::app);
			fout << endl << Reg << " " << name << " ";
			if (level == "easy")
			{
				fout << S << " " << 0 << " " << 0 << " ";

			}
			else if (level == "medium")
			{
				fout << 0 << " " << S << " " << 0 << " ";

			}
			else if (level == "hard")
			{
				fout << 0 << " " << 0 << " " << S << "  ";
			}
			fout.close();
		}
		Copy2Files("Scores2.txt", "Scores.txt");
	}


};